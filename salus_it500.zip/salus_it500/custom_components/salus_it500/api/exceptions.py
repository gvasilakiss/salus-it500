"""Exceptions raised by the Salus iT500 clients."""

from __future__ import annotations


class SalusError(Exception):
    """Base class for all Salus errors."""


class SalusAuthError(SalusError):
    """Credentials were rejected, or the session could not be established."""


class SalusConnectionError(SalusError):
    """The Salus cloud could not be reached."""


class SalusRateLimitError(SalusConnectionError):
    """Salus is throttling or has temporarily blocked this IP address."""


class SalusDeviceNotFound(SalusError):
    """The configured device ID is not present on this account."""


class SalusCommandError(SalusError):
    """A command was sent but the device or cloud rejected it."""


class SalusUnsupportedFeature(SalusError):
    """The active transport cannot perform this operation."""
