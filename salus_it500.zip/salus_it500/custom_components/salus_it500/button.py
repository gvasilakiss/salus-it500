"""Boost and schedule-override buttons for the Salus iT500."""

from __future__ import annotations

import logging

from homeassistant.components.button import ButtonEntity
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.util import dt as dt_util

from .api import HeatingMode
from .api.schedule import decode_heating, next_change
from .const import MAX_BOOST_HOURS, ZONE_CH1, ZONE_CH2, ZONE_HW
from .coordinator import SalusConfigEntry, SalusDataUpdateCoordinator
from .entity import SalusEntity, SalusZoneEntity

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: SalusConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Add boost and advance buttons for every wired zone."""
    coordinator = entry.runtime_data
    if not coordinator.client.supports_boost:
        return

    entities: list[SalusEntity] = []

    zones = [ZONE_CH1]
    if coordinator.data.has_ch2 and coordinator.client.supports_second_zone:
        zones.append(ZONE_CH2)
    if coordinator.data.hw.available:
        zones.append(ZONE_HW)

    for zone in zones:
        for hours in range(1, MAX_BOOST_HOURS + 1):
            entities.append(SalusBoostButton(coordinator, zone, hours))
        entities.append(SalusCancelBoostButton(coordinator, zone))

    if coordinator.client.supports_schedules:
        for zone in (z for z in zones if z != ZONE_HW):
            entities.append(SalusSkipButton(coordinator, zone))

    async_add_entities(entities)


class SalusBoostButton(SalusZoneEntity, ButtonEntity):
    """Start a timed boost that reverts on its own."""

    _attr_icon = "mdi:fire"

    def __init__(
        self, coordinator: SalusDataUpdateCoordinator, zone: str, hours: int
    ) -> None:
        """One button per boost duration, which is how the app presents it."""
        super().__init__(coordinator, zone, f"boost_{hours}h")
        self._hours = hours
        self._attr_name = f"{self.zone_label} boost {hours}h"

    async def async_press(self) -> None:
        """Start the boost."""
        await self.coordinator.async_command(
            lambda: self.coordinator.client.async_set_boost(self._zone, self._hours)
        )


class SalusCancelBoostButton(SalusZoneEntity, ButtonEntity):
    """Cancel a running boost."""

    _attr_icon = "mdi:fire-off"

    def __init__(self, coordinator: SalusDataUpdateCoordinator, zone: str) -> None:
        """Set the unique ID and display name."""
        super().__init__(coordinator, zone, "boost_cancel")
        self._attr_name = f"{self.zone_label} cancel boost"

    async def async_press(self) -> None:
        """Set the boost countdown to zero."""
        await self.coordinator.async_command(
            lambda: self.coordinator.client.async_set_boost(self._zone, 0)
        )


class SalusSkipButton(SalusZoneEntity, ButtonEntity):
    """Skip the next scheduled change.

    The iT500 has no native 'advance' or 'skip'. This reads today's program,
    finds the change that is coming up, and holds the current temperature
    through it - which is what skipping amounts to in practice.
    """

    _attr_icon = "mdi:skip-next"

    def __init__(self, coordinator: SalusDataUpdateCoordinator, zone: str) -> None:
        """Set the unique ID and display name."""
        super().__init__(coordinator, zone, "skip_next")
        self._attr_name = f"{self.zone_label} skip next change"

    async def async_press(self) -> None:
        """Hold the current setpoint so the next slot has no effect."""
        zone = self.heating_zone
        day = dt_util.now().strftime("%A").lower()
        slots = decode_heating(zone.programs.get(day, ""))
        upcoming = next_change(slots, dt_util.now().strftime("%H:%M"))

        if upcoming is None:
            _LOGGER.debug("No further schedule change today; nothing to skip")
            return

        hold_at = zone.target_temperature
        if hold_at is None:
            _LOGGER.debug("No current setpoint to hold; skipping the skip")
            return

        _LOGGER.debug(
            "Skipping %s change at %s by holding %.1f",
            self._zone,
            upcoming["time"],
            hold_at,
        )

        await self.coordinator.async_command(
            lambda: self.coordinator.client.async_set_heating_mode(
                self._zone, HeatingMode.TEMP_HOLD
            )
        )
        await self.coordinator.async_command(
            lambda: self.coordinator.client.async_set_target_temperature(
                self._zone, hold_at
            )
        )
