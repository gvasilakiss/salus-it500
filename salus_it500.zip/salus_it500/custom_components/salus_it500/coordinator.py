"""Polling coordinator for the Salus iT500."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from datetime import timedelta
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed, HomeAssistantError
from homeassistant.helpers.debounce import Debouncer
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import (
    DeviceState,
    SalusAuthError,
    SalusClient,
    SalusCommandError,
    SalusConnectionError,
    SalusDeviceNotFound,
    SalusError,
    SalusRateLimitError,
    SalusUnsupportedFeature,
)
from .const import DEFAULT_SCAN_INTERVAL, DOMAIN

_LOGGER = logging.getLogger(__name__)

#: The thermostat takes a few seconds to acknowledge a change through the
#: cloud, so a write is followed by a delayed confirming read rather than an
#: immediate one.
POST_COMMAND_DELAY = 4.0

type SalusConfigEntry = ConfigEntry[SalusDataUpdateCoordinator]


class SalusDataUpdateCoordinator(DataUpdateCoordinator[DeviceState]):
    """Polls the Salus cloud and serialises commands onto it."""

    config_entry: SalusConfigEntry

    def __init__(
        self,
        hass: HomeAssistant,
        entry: SalusConfigEntry,
        client: SalusClient,
        scan_interval: int = DEFAULT_SCAN_INTERVAL,
    ) -> None:
        """Set up polling at the configured interval."""
        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=f"{DOMAIN} {entry.data.get('device_id')}",
            update_interval=timedelta(seconds=scan_interval),
            request_refresh_debouncer=Debouncer(
                hass,
                _LOGGER,
                cooldown=POST_COMMAND_DELAY,
                immediate=False,
            ),
        )
        self.client = client
        self.device_id = str(entry.data.get("device_id"))

    @property
    def transport(self) -> str:
        """Which route is currently in use."""
        return self.client.transport

    async def _async_update_data(self) -> DeviceState:
        """Fetch the latest state, translating errors for Home Assistant."""
        try:
            return await self.client.async_get_state()
        except SalusAuthError as err:
            raise ConfigEntryAuthFailed(str(err)) from err
        except SalusDeviceNotFound as err:
            raise UpdateFailed(str(err)) from err
        except SalusRateLimitError as err:
            raise UpdateFailed(
                f"{err}. Consider increasing the scan interval in the "
                "integration options."
            ) from err
        except SalusConnectionError as err:
            raise UpdateFailed(str(err)) from err
        except SalusError as err:
            raise UpdateFailed(f"Unexpected Salus error: {err}") from err

    async def async_command(
        self,
        action: Callable[[], Awaitable[Any]],
        *,
        optimistic: Callable[[DeviceState], None] | None = None,
    ) -> None:
        """Run a write, optionally update local state, then confirm.

        The optimistic callback keeps the UI responsive: Salus can take the
        better part of a minute to reflect a change, and without it the
        thermostat card snaps back to the old value.
        """
        try:
            await action()
        except SalusAuthError as err:
            raise ConfigEntryAuthFailed(str(err)) from err
        except SalusUnsupportedFeature as err:
            raise HomeAssistantError(str(err)) from err
        except (SalusCommandError, SalusConnectionError) as err:
            raise HomeAssistantError(f"Salus command failed: {err}") from err

        if optimistic is not None and self.data is not None:
            optimistic(self.data)
            self.async_update_listeners()

        await self.async_request_refresh()
